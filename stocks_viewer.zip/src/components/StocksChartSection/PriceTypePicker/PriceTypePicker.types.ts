export type StockPriceType = 'open' | 'high' | 'low' | 'close';
