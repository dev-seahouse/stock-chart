export interface StocksSelectOption {
  label: string;
  value: string;
}
